#!/usr/bin/env python3
print("Arduboy Uploader GUI / FX activator v1.04 by Mr.Blinky Apr.2020\n")

from tkinter import filedialog
from tkinter import *
from tkinter.ttk import *
from threading import Thread
import sys
import os
import time

## defaults ##
fxActivator = "activator" in os.path.basename(sys.argv[0])
if len(sys.argv) > 1:
  if sys.argv[1].lower() == 'uploader' : fxActivator = False
  elif sys.argv[1].lower() == 'activator' : fxActivator = True
path = os.path.dirname(os.path.abspath(sys.argv[0]))+os.sep
if fxActivator:
  title = "FX Activator"
  defaultAppFilename = path + "arduboy-activator.hex"
else:
  title = "Arduboy uploader GUI"
  defaultAppFilename = path + "hex-file.hex"
defaultFlashFilename = path + "flash-image.bin"
selectAppInitialDir = path
selectFlashInitialDir = path

try:
  from serial.tools.list_ports  import comports
  from serial import Serial
except:
  print("The PySerial module is required but not installed!")
  print("Use 'python -m pip install pyserial' from the commandline to install.")
  time.sleep(3)
  sys.exit()

compatibledevices = [
 #Arduboy Leonardo
 "VID:PID=2341:0036", "VID:PID=2341:8036",
 "VID:PID=2A03:0036", "VID:PID=2A03:8036",
 #Arduboy Micro
 "VID:PID=2341:0037", "VID:PID=2341:8037",
 "VID:PID=2A03:0037", "VID:PID=2A03:8037",
 #Genuino Micro
 "VID:PID=2341:0237", "VID:PID=2341:8237",
 #Sparkfun Pro Micro 5V
 "VID:PID=1B4F:9205", "VID:PID=1B4F:9206",
 #Adafruit ItsyBitsy 5V
 "VID:PID=239A:000E", "VID:PID=239A:800E",
]

manufacturers = {
  0x01 : "Spansion",
  0x14 : "Cypress",
  0x1C : "EON",
  0x1F : "Adesto(Atmel)",
  0x20 : "Micron",
  0x37 : "AMIC",
  0x9D : "ISSI",
  0xC2 : "General Plus",
  0xC8 : "Giga Device",
  0xBF : "Microchip",
  0xEF : "Winbond"
}

PAGESIZE = 256
BLOCKSIZE = 65536
PAGES_PER_BLOCK = BLOCKSIZE // PAGESIZE
MAX_PAGES = 65536
bootloader_active = False

def addLog(s):
    log.insert(END, s +'\n')
    log.see("end")
    #root.update()

def delayedExit():
  time.sleep(3)
  sys.exit()

def getComPort(verbose):
  global bootloader_active
  devicelist = list(comports())
  for device in devicelist:
    for vidpid in compatibledevices:
      if  vidpid in device[2]:
        port=device[0]
        bootloader_active = (compatibledevices.index(vidpid) & 1) == 0
        if verbose : addLog("Found {} at port {}".format(device[1],port))
        return port
  if verbose : addLog("Arduboy not found. Please Check Arduboy is switched on or try a different USB cable.")

def bootloaderStart():
  global bootloader
  ## find and connect to Arduboy in bootloader mode ##
  port = getComPort(True)
  if port is None :
    return False
  if not bootloader_active:
    addLog("Selecting bootloader mode...")
    bootloader = Serial(port,1200)
    bootloader.close()
    time.sleep(0.5)	
    #wait for disconnect and reconnect in bootloader mode
    while getComPort(False) == port :
      time.sleep(0.1)
      if bootloader_active: break        
    while getComPort(False) is None : time.sleep(0.1)
    port = getComPort(True)

  log.insert(END, "Opening port..")
  log.see("end")
  root.update_idletasks()
  for retries in range(20):
    try:
      time.sleep(0.1)  
      bootloader = Serial(port, 57600)
      break
    except:
      if retries == 19:
        addLog(" Failed!")
        return False
      log.insert(END, ".")
      log.see("end")
      root.update_idletasks()
      time.sleep(0.4)
  addLog("succes")
  return True
  
def getVersion():
  bootloader.write(b"V")
  return int(bootloader.read(2))

def getJedecID():
  bootloader.write(b"j")
  jedec_id = bootloader.read(3)
  time.sleep(0.5)  
  bootloader.write(b"j")
  jedec_id2 = bootloader.read(3)
  if jedec_id2 != jedec_id or jedec_id == b'\x00\x00\x00' or jedec_id == b'\xFF\xFF\xFF':
    addLog("No flash cart detected.")
    return
  return bytearray(jedec_id)
  
def bootloaderExit():
  global bootloader
  bootloader.write(b"E")
  bootloader.read(1)
  bootloader.close()

def disableButtons():
  flashButton['state'] = DISABLED
  hexButton['state'] = DISABLED

def enableButtons():
  flashButton['state'] = NORMAL
  hexButton['state'] = NORMAL
    
## Uploader ####################################################################

def uploadHexfile():
  disableButtons()
  hexfile = appFilename.get()
  if not os.path.isfile(hexfile) :
    addLog('File not found. "{}"\n'.format(hexfile))
    enableButtons()
    return

  addLog('\nLoading "{}"\n'.format(hexfile))
  f = open(hexfile,"r")
  records = f.readlines()
  f.close()
  flash_addr = 0
  flash_data = bytearray(b'\xFF' * 32768)
  flash_page       = 1
  flash_page_count = 0
  flash_page_used  = [False] * 256
  caterina_overwrite = False
  for rcd in records :
    if rcd == ":00000001FF" : break
    if rcd[0] == ":" :
      rcd_len  = int(rcd[1:3],16)
      rcd_typ  = int(rcd[7:9],16)
      rcd_addr = int(rcd[3:7],16)
      rcd_sum  = int(rcd[9+rcd_len*2:11+rcd_len*2],16)
      if (rcd_typ == 0) and (rcd_len > 0) :
        flash_addr = rcd_addr
        flash_page_used[int(rcd_addr / 128)] = True
        flash_page_used[int((rcd_addr + rcd_len - 1) / 128)] = True
        checksum = rcd_sum
        for i in range(1,9+rcd_len*2, 2) :
          byte = int(rcd[i:i+2],16)
          checksum = (checksum + byte) & 0xFF
          if i >= 9:
            flash_data[flash_addr] = byte
            flash_addr += 1
        if checksum != 0 :
          addLog("Hex file contains errors. upload aborted.")
          enableButtons()
          return
  
  ## check  for data in catarina bootloader area ##  
  for i in range (256) :
    if flash_page_used[i] :
      flash_page_count += 1
      if i >= 224 :
        caterina_overwrite = True
  progressbar['value'] = 0
  progressbar['maximum'] = 512
  if not bootloaderStart(): 
    enableButtons()
    return
  
  #test if bootloader can and will be overwritten by hex file
  bootloader.write(b"V") #get bootloader software version
  if bootloader.read(2) == b"10" : #original caterina 1.0 bootloader
    bootloader.write(b"r") #read lock bits
    if (ord(bootloader.read(1)) & 0x10 != 0) and caterina_overwrite :
      addLog("This upload will most likely corrupt the catarina bootloader. Upload aborted.")
      bootloaderExit()
      enableButtons()
      return
      
  ## Flash ##
  addLog("Flashing {} bytes. ({} flash pages)".format(flash_page_count * 128, flash_page_count))
  for i in range (256) :
    if flash_page_used[i] :
      bootloader.write(bytearray([ord("A"), i >> 2, (i & 3) << 6]))
      bootloader.read(1)
      bootloader.write(b"B\x00\x80F")
      bootloader.write(flash_data[i * 128 : (i + 1) * 128])
      bootloader.read(1)
      flash_page += 1
    progressbar.step()
    root.update_idletasks()
  
  ## Verify ##
  addLog("Verifying {} bytes. ({} flash pages)".format(flash_page_count * 128, flash_page_count))
  for i in range (256) :
    if flash_page_used[i] :
      bootloader.write(bytearray([ord("A"), i >> 2, (i & 3) << 6]))
      bootloader.read(1)
      bootloader.write(b"g\x00\x80F")
      if bootloader.read(128) != flash_data[i * 128 : (i + 1) * 128] :
        addLog("Verify failed at address {:04X}. Upload unsuccessful.\n".format(i * 128))
        bootloaderExit()
        enableButtons()
        return
      flash_page += 1
    progressbar['value'] = progressbar['value'] + 1
    root.update_idletasks()
  
  addLog("\nUpload success!!")
  bootloaderExit()      
  enableButtons()
  
## flasher #####################################################################

def flashImage():
  disableButtons()
  progressbar['value'] = 0
  filename = flashFilename.get()
  ## load and pad imagedata to multiple of PAGESIZE bytes ##
  if not os.path.isfile(filename):
    addLog('File not found. "{}" \n'.format(filename))
    enableButtons()
    return()
    
  addLog('\nLoading flash image from file "{}"\n'.format(filename))
  f = open(filename,"rb")
  flashdata = bytearray(f.read())
  f.close
  if (len(flashdata) % PAGESIZE != 0):
    flashdata += b'\xFF' * (PAGESIZE - (len(flashdata) % PAGESIZE))
  pagenumber = 0
  if not bootloaderStart(): 
    enableButtons()
    return

  #check version
  if getVersion() < 13:
    addLog("Bootloader does not support writing to flash. Write aborted!\nPlease update bootloader first.")
    enableButtons()
    return
  
  ## detect flash cart ##
  jedec_id = getJedecID()
  if jedec_id[0] in manufacturers.keys():
    manufacturer = manufacturers[jedec_id[0]]
  else:
    manufacturer = "unknown"
  capacity = 1 << jedec_id[2]
  addLog("\nFlash JEDEC ID    : {:02X}{:02X}{:02X}".format(jedec_id[0],jedec_id[1],jedec_id[2]))
  addLog("Flash Manufacturer: {}".format(manufacturer))
  if manufacturer != "unknown": addLog("Flash capacity    : {} KB\n".format(capacity // 1024))
    
  # when ending partially in a block, preserve the ending of old block data
  if len(flashdata) % BLOCKSIZE:
    blocklen = BLOCKSIZE - len(flashdata) % BLOCKSIZE
    blockaddr = pagenumber + len(flashdata) // PAGESIZE     
    #read partial block data end
    bootloader.write(bytearray([ord("A"), blockaddr >> 8, blockaddr & 0xFF]))
    bootloader.read(1)
    bootloader.write(bytearray([ord("g"), (blocklen >> 8) & 0xFF, blocklen & 0xFF,ord("C")]))
    flashdata += bootloader.read(blocklen)

  ## write to flash cart ##
  verifyAfterWrite = flashVerify.get()
  blocks = len(flashdata) // BLOCKSIZE
  log.insert(END,"writing {} blocks/{}KB to flash".format(blocks, len(flashdata) // 1024))
  if verifyAfterWrite:
    addLog(" with verify")
  else:
    addLog("")
  progressbar['maximum'] = 2 * blocks
  for block in range (blocks):
    if (block & 1 == 0) or verifyAfterWrite:
      bootloader.write(b"x\xC2") #RGB LED RED, buttons disabled
    else:  
      bootloader.write(b"x\xC0") #RGB LED OFF, buttons disabled
    bootloader.read(1)
    blockaddr = pagenumber + block * BLOCKSIZE // PAGESIZE
    blocklen = BLOCKSIZE
    #write block 
    bootloader.write(bytearray([ord("A"), blockaddr >> 8, blockaddr & 0xFF]))
    bootloader.read(1)
    bootloader.write(bytearray([ord("B"), (blocklen >> 8) & 0xFF, blocklen & 0xFF,ord("C")]))
    bootloader.write(flashdata[block * BLOCKSIZE : block * BLOCKSIZE + blocklen])
    bootloader.read(1)
    progressbar.step()
    root.update_idletasks()
    if verifyAfterWrite:
      bootloader.write(b"x\xC1") #RGB BLUE RED, buttons disabled
      bootloader.read(1)
      bootloader.write(bytearray([ord("A"), blockaddr >> 8, blockaddr & 0xFF]))
      bootloader.read(1)
      bootloader.write(bytearray([ord("g"), (blocklen >> 8) & 0xFF, blocklen & 0xFF,ord("C")]))
      if bootloader.read(blocklen) != flashdata[block * BLOCKSIZE : block * BLOCKSIZE + blocklen]:
        addLog(" verify failed!\n\nWrite aborted.")
        break
    progressbar['value'] = progressbar['value'] + 1
    root.update_idletasks()
  
  #write complete  
  bootloader.write(b"x\xC4")#RGB LED GREEN, buttons disabled
  bootloader.read(1)
  time.sleep(0.5)           #keep LED on for half a second
  bootloader.write(b"x\x40")#RGB LED OFF, buttons enabled
  bootloader.read(1)
  bootloaderExit()
  addLog("\nUploaded flash image successfully!!\n")
  addLog("Press LEFT or RIGHT on Arduboy to browse through the game catagogories.")
  addLog("Press UP or DOWN to select a game followed by A or B to load and play a game.")
  addLog("Press A or B on the Loader title screen to play last loaded game.")
  enableButtons()
  
## backup EEPROM ###############################################################

## restore EEPROM ##############################################################

## erase EEPROM ################################################################

def eraseEEPROM():
  disableButtons()
  progressbar['value'] = 0
  progressbar['maximum'] = 1024
  if not bootloaderStart(): 
    enableButtons()
    return  
  addLog("\nErasing EEPROM data...")
  for addr in range(0,1024,64):
    bootloader.write(bytearray([ord("A"),addr >> 8,addr & 0xFF]))
    bootloader.read(1)
    bootloader.write(b"B\x00\x40E")
    bootloader.write(b"\xFF" * 64)
    bootloader.read(1)
    progressbar['value'] = progressbar['value'] + 64
  bootloaderExit()
  addLog("EEPROM erase complete.")
  enableButtons()
 
## GUI interface ###############################################################

## menu commands ##

def selectHexFile():
    global selectAppInitialDir
    selectHexFilename = filedialog.askopenfilename(initialdir = selectAppInitialDir, title = "Select Hex file",filetypes = (("hex files","*.hex"),("all files","*.*")))    
    if selectHexFilename != '':
        selectAppInitialDir = os.path.dirname(selectHexFilename)+os.sep
        appFilename.set(selectHexFilename)

def selectFlashFile():
    global selectFlashInitialDir
    selectFlashFilename = filedialog.askopenfilename(initialdir = selectFlashInitialDir, title = "Select Flash image",filetypes = (("bin files","*.bin"),("all files","*.*")))    
    if selectFlashFilename != '':
        selectFlashInitialDir = os.path.dirname(selectFlashFilename)+os.sep
        flashFilename.set(selectFlashFilename)
    
def ClearLog():
    log.delete(1.0, END)

def uploadHexfileThread():
  Thread(target = uploadHexfile).start()
  
def flashImageThread():
  Thread(target = flashImage).start()

def backupEEPROMThread():
  Thread(target = backupEEPROM).start()
  
def restoreEEPROMThread():
  Thread(target = restoreEEPROM).start()

def eraseEEPROMThread():
  Thread(target = eraseEEPROM).start()
  
## events ##

def OnResize(event):
    pass

def selectHexFileHotKey(event):
    selectHexFile()

def selectFlashFileHotKey(event):
    selectFlashFile()
    
def ExitAppHotKey(event):
    root.quit()
    
## create form and widgets ##

root = Tk()
root.geometry("700x400")
root.title(title + " v1.04")
try:
  root.iconbitmap("icon.ico")
except:
  pass
#add progress bar at bottom (first ensure Vscrollbar rests on progress bar)
progressbar=Progressbar(root, orient='horizontal', mode='determinate')
progressbar.pack(side="bottom", expand=False, fill='both')

#add app button and selector frame
appFrame = Frame(root)
appFrame.pack(side = TOP, fill = BOTH)
appFilename = StringVar(appFrame, value = defaultAppFilename)
hexButton = Button(appFrame, text="Upload Hex file", width = 20, command = uploadHexfileThread)
hexButton.pack(side = LEFT)
hexDirButton = Button(appFrame, text="...", width = 2, command = selectHexFile).pack(side = RIGHT)
hexEntry = Entry(appFrame, textvariable = appFilename).pack(side = LEFT, expand = True, fill = X)

#add flash button and selector frame
flashFrame = Frame(root)
flashFrame.pack(side = TOP, fill = BOTH)
flashFilename = StringVar(flashFrame, value = defaultFlashFilename)
flashButton = Button(flashFrame, text="Upload Flash image", width = 20, command = flashImageThread)
flashButton.pack(side = LEFT)
flashDirButton = Button(flashFrame, text="...", width = 2, command = selectFlashFile).pack(side = RIGHT)
flashEntry = Entry(flashFrame, textvariable = flashFilename).pack(side = LEFT, expand = True, fill = X)

#create log text area with scrollbar
scrollbar = Scrollbar(root)
scrollbar.pack(side = RIGHT, fill = Y)
log = Text(root, wrap = NONE, yscrollcommand = scrollbar.set)
scrollbar.config(command = log.yview)

#Menu checkmarks
appVerify = BooleanVar()
flashVerify  = BooleanVar()

#create menus
mainmenu = Menu(root)
filemenu = Menu(mainmenu, tearoff=0)
filemenu.add_command(label = "Select Hex file", underline = 1, accelerator = "Ctrl + H", command = selectHexFile)
filemenu.add_command(label = "Select Flash image", underline = 1, accelerator = "Ctrl + F", command = selectFlashFile)
if not fxActivator:
  filemenu.add_separator()
  filemenu.add_command(label = "Backup EEPROM", underline = 1, accelerator = "Ctrl + B", command = backupEEPROMThread)
  filemenu.add_command(label = "Restore EEPROM", underline = 1, accelerator = "Ctrl + R", command = restoreEEPROMThread)
  filemenu.add_command(label = "Erase EEPROM", underline = 1, command = eraseEEPROMThread)
  filemenu.add_separator()
filemenu.add_command(label = "Exit", underline = 1, accelerator = "Ctrl + X", command = root.quit)
optionmenu = Menu(mainmenu, tearoff = 0)
optionmenu.add_checkbutton(label="Verify Hex file after upload",onvalue=True,offvalue=False,variable=appVerify)
appVerify.set(True)
optionmenu.add_checkbutton(label="Upload Flash image without verify",onvalue=False,offvalue=True,variable=flashVerify)
#flashVerify.set(True)
optionmenu.add_command(label="Clear log",command=ClearLog)
mainmenu.add_cascade(label="File", menu = filemenu)
mainmenu.add_cascade(label="Options", menu = optionmenu)
root.config(menu=mainmenu)

# default log
if fxActivator:
  addLog("\nArduboy FX activator v1.04 Apr-Aug 2020 by Mr.Blinky.\n\nInstructions:\n-------------\n1) Connect Arduboy and turn power on.\n2) Click Upload Hex file button and wait for upload to complete.\n3) Run Flash mod chip option on Arduboy.\n4) Run Flash bootloader option on Arduboy.\n5) Click Upload Flash image button and wait for upload to complete.\n6) Enjoy your Arduboy FX.\n")
else:
  addLog("\nArduboy uploader GUI v1.04 Apr-Aug 2020 by Mr.Blinky.\n\n1) Use File menu or […] button to browse for a Hex file or Flash image.\n2) Press the appropriate upload button to upload the file.\n")
log.pack(side="top", expand=True, fill='both')
log.bind("<Configure>", OnResize)

#create hot keys
root.bind_all("<Control-x>", ExitAppHotKey)
root.bind_all("<Control-h>", selectHexFileHotKey)
root.bind_all("<Control-f>", selectFlashFileHotKey)

#run application
root.mainloop()